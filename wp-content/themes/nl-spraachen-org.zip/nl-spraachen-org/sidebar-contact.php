<?php if (is_active_sidebar('contact-sidebar')) : ?>

    
    <?php dynamic_sidebar('contact-sidebar'); ?>

<?php endif; ?>